export MCVER="1.7.10"
export JARFILE="minecraft_server.${MCVER}.jar"
export LAUNCHWRAPPER="net/minecraft/launchwrapper/1.12/launchwrapper-1.12.jar"
export JAVACMD="java"

