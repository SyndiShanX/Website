#using scripts\shared\callbacks_shared;
#using scripts\shared\hud_util_shared;
#using scripts\shared\system_shared;

#insert scripts\shared\shared.gsh;

#namespace clientids;

REGISTER_SYSTEM("clientids", &__init__, undefined)

function __init__() {
	callback::on_start_gametype(&init);
}

function init() {
	setDvar("sv_cheats", "1");

	level thread player_connect();

	wait 0.5;
}

function player_connect() {
	level endon("game_ended");

	for(;;) {
		level waittill("connected", player);
		
		wait 10;
		
		for(;;) {
			player iPrintString("Example Text Popup");
			wait 2.5;
		}
	}
}

function iPrintString(string) {
	if(!isDefined(self.menu["string"])) {
	  self.menu["string"] = self create_text(string, "default", 1.5, "center", "top", 0, -115, (1, 1, 1), 1, 9999, false);
	} else {
	  self.menu["string"] set_text(string);
	}
	self.menu["string"] notify("stop_hud_fade");
	self.menu["string"].alpha = 1;
	self.menu["string"] setText(string);
	self.menu["string"] thread fade_hud(0, 2.5);
}

function fade_hud(alpha, time) {
	self endon("stop_hud_fade");
	self fadeOverTime(time);
	self.alpha = alpha;
	wait time;
}

function create_text(text, font, font_scale, align_x, align_y, x_offset, y_offset, color, alpha, z_index, hide_when_in_menu) {
	textElement = self hud::createFontString(font, font_scale);
	textElement hud::setPoint(align_x, align_y, x_offset, y_offset);

	textElement.alpha = alpha;
	textElement.sort = z_index;
	textElement.anchor = self;
	textElement.archived = self auto_archive();

	if(isDefined(hide_when_in_menu)) {
		textElement.hideWhenInMenu = hide_when_in_menu;
	} else {
		textElement.hideWhenInMenu = true;
	}

	if(isDefined(color)) {
		textElement.color = color;
	} else {
		textElement.color = (0, 1, 1);
	}

	if(isDefined(text)) {
		if(strisNumber(text)) {
			textElement setValue(text);
		} else {
			textElement set_text(text);
		}
	}

	self.element_result++;
	return textElement;
}

function set_text(text) {
	if(!isDefined(self) || !isDefined(text)) {
		return;
	}

	self.text = text;
	self setText(text);
}

function auto_archive() {
	if(!isDefined(self.element_result)) {
		self.element_result = 0;
	}

	if(!isAlive(self) || self.element_result > 21) {
		return true;
	}

	return false;
}